// Function to create a new task
function createTask(id, description, status, creationDate, deadline, priority) {
    return {
      id,
      description,
      status: status || false,
      creationDate: creationDate || new Date(),
      deadline: deadline || null,
      priority: priority || "Normal", // "Low", "Normal", "High" by default
    };
  }
  
  // List of tasks
  let tasksList = [];
  
  // Function to add a task to the list
  function addTask(task) {
    tasksList.push(task);
  }
  
  // Function to display the list of tasks
  function showTasksList() {
    console.log("**To-Do List**");
    for (const task of tasksList) {
      let statusStr = task.status ? "Completed" : "Not completed";
      let deadlineStr = task.deadline ? task.deadline.toLocaleDateString() : "No deadline";
      console.log(`- ${task.id}: ${task.description} - ${statusStr} - ${deadlineStr} - Priority: ${task.priority}`);
    }
  }
  
  // Function to change the status of a task
  function changeTaskStatus(id, newStatus) {
    const task = tasksList.find((t) => t.id === id);
    if (task) {
      task.status = newStatus;
      console.log(`**Task updated:** ${task.id}`);
    } else {
      console.log(`**Error:** Task with id ${id} not found`);
    }
  }
  
  // Function to filter by status
  function showTasksByStatus(status) {
    console.log(`**Tasks ${status ? "completed" : "not completed"}:**`);
    for (const task of tasksList) {
      if (task.status === status) {
        console.log(`- ${task.id}: ${task.description}`);
      }
    }
  }
  
  // Function to filter by creation date
  function showTasksByCreationDate(startDate, endDate) {
    console.log(`**Tasks created between ${startDate.toLocaleDateString()} and ${endDate.toLocaleDateString()}:**`);
    for (const task of tasksList) {
      if (task.creationDate >= startDate && task.creationDate <= endDate) {
        console.log(`- ${task.id}: ${task.description}`);
      }
    }
  }
  
  // Example of use
  const task1 = createTask("A", "Buy tomatoes", false, new Date(), new Date(2024, 2, 15), "High");
  const task2 = createTask("B", "Clean the house", false, new Date(), null, "Normal");
  const task3 = createTask("C", "Prepare dinner", true, new Date(), new Date(2024, 2, 14), "Low");
  
  addTask(task1);
  addTask(task2);
  addTask(task3);
  
  showTasksList();
  
  // Change the status of a task
  changeTaskStatus("B", true);
  
  // Show tasks by status
  showTasksByStatus(true);
  
  // Show tasks by creation date
  showTasksByCreationDate(new Date(2024, 2, 10), new Date(2024, 2, 15));
  
  

  