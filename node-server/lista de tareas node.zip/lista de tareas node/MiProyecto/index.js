// Importa las dependencias que necesitas
const express = require('express');
const readline = require('readline');

// Crea una aplicación Express
const app = express();

// Define las rutas de tu aplicación
app.get('/', (req, res) => {
  res.send('¡Hola mundo!');
});

// Función para mostrar las opciones disponibles
function mostrarOpciones() {
  console.log('**Elige una función:**');
  console.log('1. Agregar tarea');
  console.log('2. Mostrar lista de tareas');
  console.log('3. Eliminar tarea');
  console.log('4. Completar tarea');
  console.log('5. Salir');
}

// Función para leer la entrada del usuario
function leerEntrada() {
  rl.question('> ', (opcion) => {
    switch (opcion) {
      case '1':
        console.log('Ejecutando función agregar tarea');
        agregarTarea();
        break;
      case '2':
        console.log('Ejecutando función mostrar lista de tareas');
        mostrarListaTareas();
        break;
      case '3':
        console.log('Ejecutando función eliminar tarea');
        eliminarTarea();
        break;
      case '4':
        console.log('Ejecutando función completar tarea');
        completarTarea();
        break;
      case '5':
        console.log('Saliendo...');
        rl.close();
        break;
      default:
        console.log('Opción no válida');
        break;
    }
    mostrarOpciones();
    leerEntrada();
  });
}

// Función para agregar una tarea
function agregarTarea() {
  // Aquí va el código para agregar la tarea a la lista
  // Por ejemplo, puedes usar un array para almacenar las tareas
  const tarea = readline.question('Introduce la nueva tarea: ');
  tareas.push(tarea);
  console.log('Tarea agregada correctamente');
}

// Función para mostrar la lista de tareas
function mostrarListaTareas() {
  // Aquí va el código para mostrar la lista de tareas
  // Por ejemplo, puedes usar un bucle para recorrer el array de tareas
  console.log('**Lista de tareas:**');
  for (let i = 0; i < tareas.length; i++) {
    console.log(`${i + 1}. ${tareas[i]}`);
  }
}

// Función para eliminar una tarea
function eliminarTarea() {
  // Aquí va el código para eliminar la tarea de la lista
  // Por ejemplo, puedes usar un array para almacenar las tareas
  const indice = parseInt(readline.question('Introduce el índice de la tarea a eliminar: '));
  tareas.splice(indice - 1, 1);
  console.log('Tarea eliminada correctamente');
}

// Función para completar una tarea
function completarTarea() {
  // Aquí va el código para marcar la tarea como completada
  // Por ejemplo, puedes usar una propiedad `completada` en cada tarea
  const indice = parseInt(readline.question('Introduce el índice de la tarea a completar: '));
  tareas[indice - 1].completada = true;
  console.log('Tarea completada correctamente');
}

// Crea una interfaz readline
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Inicializa la lista de tareas
let tareas = [];

// Iniciar la aplicación
mostrarOpciones();
leerEntrada();

// Inicia la aplicación Express en el puerto 3000
app.listen(5000, () => {
  console.log('Aplicación iniciada en el puerto 3000');
});
